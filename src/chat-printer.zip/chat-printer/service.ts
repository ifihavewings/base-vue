

import axios, { request, post, get } from "@/request"
import {type IAxiosRequestConfig} from "@/request/types"
export const chat = (data:any = {}, cfg?:any) => {
    return request({
        url: '/nest/chat/stream',
        data,
        method: "get",
        ...(cfg as IAxiosRequestConfig), 
    })
}
